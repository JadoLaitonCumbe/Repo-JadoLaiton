import os
import tempfile
import re
import json
import uuid
import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from datetime import datetime, timezone
from fastapi.testclient import TestClient

_fd, _db_path = tempfile.mkstemp(suffix=".db")
os.environ["DATABASE_PATH"] = _db_path
os.environ["APP_SECRET_KEY"] = "test-secret-key-for-tests-only-123456789-abcdef"
os.environ["APP_MODE"] = "development"
from app.main import app, _RATE


def csrf(html):
    match = re.search(r'name="csrf_token" value="([^"]+)"', html)
    assert match, "CSRF token not present in form"
    return match.group(1)


def register_company(client, name="Empresa Teste", username=None):
    _RATE.clear()  # isolate test cases; rate-limit behavior is not under test here
    username = username or ("empresa_" + uuid.uuid4().hex[:10])
    page = client.get("/registo")
    response = client.post("/registo", data={
        "csrf_token": csrf(page.text), "company_name": name, "username": username,
        "password": "SenhaMuitoForte123!"
    })
    assert response.status_code == 200, response.text
    code_match = re.search(r"ATJ-[A-F0-9]+-[A-F0-9]+", response.text)
    assert code_match, response.text
    return code_match.group(0)


def test_home_and_health():
    with TestClient(app, base_url="http://localhost") as client:
        assert client.get("/").status_code == 200
        assert client.get("/health").json()["status"] == "ok"
        assert client.get("/").headers["x-frame-options"] == "DENY"


def test_company_registration_and_dashboard_and_csrf():
    with TestClient(app, base_url="http://localhost") as client:
        register_company(client)
        dashboard = client.get("/dashboard")
        assert dashboard.status_code == 200
        assert "Empresa Teste" in dashboard.text
        # Missing CSRF token must be rejected.
        bad = client.post("/financeiro/movimento", data={"kind":"receita","category":"Vendas","description":"Venda","amount":"10,00"})
        assert bad.status_code == 422 or bad.status_code == 403


def test_activation_is_one_time_and_sync_requires_bearer_token():
    with TestClient(app, base_url="http://localhost") as client:
        code = register_company(client)
        device_id = str(uuid.uuid4())
        activated = client.post("/api/device/activate", json={"activation_code": code, "device_id": device_id})
        assert activated.status_code == 200, activated.text
        data = activated.json()
        assert data["device_token"]
        second_device = client.post("/api/device/activate", json={"activation_code": code, "device_id": str(uuid.uuid4())})
        assert second_device.status_code == 403
        event = {"event_id": str(uuid.uuid4()), "kind":"receita", "category":"Vendas", "description":"Venda offline", "amount_cents": 12550, "occurred_at": datetime.now(timezone.utc).isoformat()}
        denied = client.post("/api/sync/push", json={"device_id":device_id,"events":[event]})
        assert denied.status_code == 401
        result = client.post("/api/sync/push", headers={"Authorization":"Bearer "+data["device_token"]}, json={"device_id":device_id,"events":[event]})
        assert result.status_code == 200, result.text
        assert result.json()["created"] == [event["event_id"]]
        again = client.post("/api/sync/push", headers={"Authorization":"Bearer "+data["device_token"]}, json={"device_id":device_id,"events":[event]})
        assert again.json()["duplicate"] == [event["event_id"]]
        conflict_event = dict(event, amount_cents=99999)
        conflict = client.post("/api/sync/push", headers={"Authorization":"Bearer "+data["device_token"]}, json={"device_id":device_id,"events":[conflict_event]})
        assert conflict.json()["conflicts"][0]["event_id"] == event["event_id"]


def test_sync_rejects_non_finite_amount_without_rolling_back_other_events():
    with TestClient(app, base_url="http://localhost") as client:
        code = register_company(client, "Empresa Finita", "empresa_finita")
        device_id = str(uuid.uuid4())
        activated = client.post("/api/device/activate", json={"activation_code":code,"device_id":device_id}).json()
        good = {"event_id":str(uuid.uuid4()),"kind":"despesa","category":"Renda","description":"Aluguer","amount_cents":12000,"occurred_at":datetime.now(timezone.utc).isoformat()}
        bad = {"event_id":str(uuid.uuid4()),"kind":"receita","category":"Vendas","description":"Infinito","amount_cents":float("inf"),"occurred_at":datetime.now(timezone.utc).isoformat()}
        response = client.post("/api/sync/push", headers={"Authorization":"Bearer "+activated["device_token"], "Content-Type":"application/json"}, content=json.dumps({"device_id":device_id,"events":[bad,good]}, allow_nan=True))
        assert response.status_code == 200, response.text
        assert len(response.json()["created"]) == 1
        assert len(response.json()["rejected"]) == 1


def test_money_validation_and_tenant_isolation():
    from app.main import validate_amount
    assert validate_amount("1.005") == 101
    assert validate_amount("0,285") == 29
    for value in ("inf", "Infinity", "1e400", "1.234,56"):
        try:
            validate_amount(value)
            assert False, f"should reject {value}"
        except ValueError:
            pass
    with TestClient(app, base_url="http://localhost") as client_a, TestClient(app, base_url="http://localhost") as client_b:
        # Tenant isolation: company B cannot see company A's dashboard without its own session.
        register_company(client_a, "Empresa A", "empresa_a")
        assert client_b.get("/dashboard").status_code == 401


def test_device_cannot_be_reassigned_to_another_company():
    with TestClient(app, base_url="http://localhost") as client:
        code_a = register_company(client, "Empresa A", "empresa_a_reassign")
        device_id = str(uuid.uuid4())
        first = client.post("/api/device/activate", json={"activation_code":code_a,"device_id":device_id})
        assert first.status_code == 200
        code_b = register_company(client, "Empresa B", "empresa_b_reassign")
        attempt = client.post("/api/device/activate", json={"activation_code":code_b,"device_id":device_id})
        assert attempt.status_code == 409


def test_sync_idempotency_is_scoped_to_company():
    with TestClient(app, base_url="http://localhost") as client:
        code_a = register_company(client, "Tenant A", "tenant_a_scope")
        dev_a = str(uuid.uuid4())
        token_a = client.post("/api/device/activate", json={"activation_code":code_a,"device_id":dev_a}).json()["device_token"]
        code_b = register_company(client, "Tenant B", "tenant_b_scope")
        dev_b = str(uuid.uuid4())
        token_b = client.post("/api/device/activate", json={"activation_code":code_b,"device_id":dev_b}).json()["device_token"]
        shared_event_id = str(uuid.uuid4())
        event_a = {"event_id":shared_event_id,"kind":"receita","category":"Vendas","description":"A","amount_cents":100,"occurred_at":datetime.now(timezone.utc).isoformat()}
        event_b = dict(event_a, description="B", amount_cents=200)
        res_a = client.post("/api/sync/push", headers={"Authorization":"Bearer "+token_a}, json={"device_id":dev_a,"events":[event_a]})
        res_b = client.post("/api/sync/push", headers={"Authorization":"Bearer "+token_b}, json={"device_id":dev_b,"events":[event_b]})
        assert res_a.json()["created"] == [shared_event_id]
        assert res_b.json()["created"] == [shared_event_id]
