import os
import sqlite3
from pathlib import Path

DB_PATH = os.getenv("DATABASE_PATH", "./business_hybrid.db")


def connect():
    Path(DB_PATH).parent.mkdir(parents=True, exist_ok=True)
    conn = sqlite3.connect(DB_PATH, check_same_thread=False, timeout=15)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA foreign_keys = ON")
    conn.execute("PRAGMA journal_mode = WAL")
    conn.execute("PRAGMA busy_timeout = 15000")
    return conn


def init_db():
    with connect() as db:
        db.executescript("""
        CREATE TABLE IF NOT EXISTS companies (
            id TEXT PRIMARY KEY, name TEXT NOT NULL, username TEXT UNIQUE NOT NULL,
            password_hash TEXT NOT NULL, activation_code_hash TEXT,
            activation_expires_at TEXT, activation_used_at TEXT,
            created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
        );
        CREATE TABLE IF NOT EXISTS transactions (
            id TEXT NOT NULL, company_id TEXT NOT NULL, kind TEXT NOT NULL,
            category TEXT NOT NULL, description TEXT NOT NULL, amount_cents INTEGER NOT NULL CHECK(amount_cents > 0),
            occurred_at TEXT NOT NULL, source TEXT NOT NULL DEFAULT 'online',
            synced INTEGER NOT NULL DEFAULT 1, created_by TEXT, device_id TEXT,
            PRIMARY KEY(company_id, id), FOREIGN KEY(company_id) REFERENCES companies(id)
        );
        CREATE INDEX IF NOT EXISTS idx_transactions_company_date ON transactions(company_id, occurred_at);
        CREATE TABLE IF NOT EXISTS activation_devices (
            device_id TEXT PRIMARY KEY, company_id TEXT NOT NULL, token_hash TEXT NOT NULL,
            activated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP, revoked_at TEXT,
            FOREIGN KEY(company_id) REFERENCES companies(id)
        );
        CREATE TABLE IF NOT EXISTS audit_log (
            id INTEGER PRIMARY KEY AUTOINCREMENT, company_id TEXT NOT NULL, actor TEXT NOT NULL,
            action TEXT NOT NULL, object_id TEXT, detail TEXT NOT NULL DEFAULT '',
            created_at TEXT NOT NULL, FOREIGN KEY(company_id) REFERENCES companies(id)
        );
        CREATE TABLE IF NOT EXISTS auth_attempts (
            key TEXT PRIMARY KEY, attempts INTEGER NOT NULL, window_start REAL NOT NULL
        );
        """)
        # Migrate databases created by the previous MVP version.
        company_cols = {r["name"] for r in db.execute("PRAGMA table_info(companies)").fetchall()}
        if "activation_code" in company_cols and "activation_code_hash" not in company_cols:
            db.execute("ALTER TABLE companies ADD COLUMN activation_code_hash TEXT")
            db.execute("ALTER TABLE companies ADD COLUMN activation_expires_at TEXT")
            db.execute("ALTER TABLE companies ADD COLUMN activation_used_at TEXT")
            # Legacy plaintext codes are intentionally invalidated; keep only a non-secret tombstone
            # because old schemas declared activation_code NOT NULL.
            db.execute("UPDATE companies SET activation_code='INVALIDATED-' || id, activation_code_hash=NULL, activation_expires_at=NULL, activation_used_at=NULL")
        elif "activation_code" in company_cols:
            # Finish migration safely if a previous deployment added the hash columns but retained plaintext codes.
            db.execute("UPDATE companies SET activation_code='INVALIDATED-' || id WHERE activation_code_hash IS NULL OR activation_code_hash=''")
        tx_cols = {r["name"] for r in db.execute("PRAGMA table_info(transactions)").fetchall()}
        pk_cols = [r["name"] for r in db.execute("PRAGMA table_info(transactions)").fetchall() if r["pk"]]
        if pk_cols == ["id"]:
            db.execute("ALTER TABLE transactions RENAME TO transactions_legacy")
            db.executescript("""
            CREATE TABLE transactions (
                id TEXT NOT NULL, company_id TEXT NOT NULL, kind TEXT NOT NULL,
                category TEXT NOT NULL, description TEXT NOT NULL, amount_cents INTEGER NOT NULL CHECK(amount_cents > 0),
                occurred_at TEXT NOT NULL, source TEXT NOT NULL DEFAULT 'online', synced INTEGER NOT NULL DEFAULT 1,
                created_by TEXT, device_id TEXT, PRIMARY KEY(company_id,id), FOREIGN KEY(company_id) REFERENCES companies(id)
            );
            INSERT OR IGNORE INTO transactions(id,company_id,kind,category,description,amount_cents,occurred_at,source,synced)
              SELECT id,company_id,kind,category,description,amount_cents,occurred_at,source,synced FROM transactions_legacy;
            DROP TABLE transactions_legacy;
            CREATE INDEX IF NOT EXISTS idx_transactions_company_date ON transactions(company_id, occurred_at);
            """)
        device_cols = {r["name"] for r in db.execute("PRAGMA table_info(activation_devices)").fetchall()}
        if "token_hash" not in device_cols:
            db.execute("ALTER TABLE activation_devices ADD COLUMN token_hash TEXT NOT NULL DEFAULT ''")
            db.execute("ALTER TABLE activation_devices ADD COLUMN revoked_at TEXT")
            db.execute("UPDATE activation_devices SET revoked_at=CURRENT_TIMESTAMP WHERE token_hash='' ")
