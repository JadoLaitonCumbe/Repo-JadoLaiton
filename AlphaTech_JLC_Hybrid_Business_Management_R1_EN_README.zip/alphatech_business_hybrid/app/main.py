from contextlib import asynccontextmanager
from datetime import datetime, timedelta, timezone
from decimal import Decimal, InvalidOperation, ROUND_HALF_UP, localcontext
from pathlib import Path
from uuid import UUID, uuid4
import hashlib
import hmac
import json
import os
import secrets
import time

# Load .env explicitly without overriding real environment variables.
ROOT_DIR = Path(__file__).resolve().parent.parent
_env_file = ROOT_DIR / ".env"
if _env_file.exists():
    for _line in _env_file.read_text(encoding="utf-8").splitlines():
        _line = _line.strip()
        if _line and not _line.startswith("#") and "=" in _line:
            _k, _v = _line.split("=", 1)
            os.environ.setdefault(_k.strip(), _v.strip().strip('"').strip("'"))

from fastapi import FastAPI, Form, Request, HTTPException, Header
from fastapi.responses import HTMLResponse, RedirectResponse
from fastapi.staticfiles import StaticFiles
from fastapi.templating import Jinja2Templates
from starlette.middleware.sessions import SessionMiddleware

from .db import connect, init_db
from .security import hash_password, verify_password, make_activation_code, secret_key, hash_secret, csrf_token, normalize_timestamp, utc_now_iso

BASE_DIR = Path(__file__).resolve().parent

def _is_production():
    return os.getenv("APP_MODE", "development").lower() == "production"

@asynccontextmanager
async def lifespan(app: FastAPI):
    # Force secret validation at startup, not after serving requests.
    secret_key()
    init_db()
    yield

app = FastAPI(title="AlphaTech-JLC | Gestão Empresarial Híbrida", version="0.2.0", lifespan=lifespan,
              docs_url=None if _is_production() else "/docs", redoc_url=None if _is_production() else "/redoc",
              openapi_url=None if _is_production() else "/openapi.json")
app.add_middleware(SessionMiddleware, secret_key=secret_key(), same_site="lax", https_only=_is_production(), max_age=60*60*8)
app.mount("/static", StaticFiles(directory=BASE_DIR / "static"), name="static")
templates = Jinja2Templates(directory=BASE_DIR / "templates")

# Simple process-local limiter for the MVP. Production should use a shared Redis limiter.
_RATE: dict[str, list[float]] = {}
def rate_limit(key: str, limit: int = 8, window: int = 300):
    now = time.time()
    entries = [t for t in _RATE.get(key, []) if now - t < window]
    if len(entries) >= limit:
        raise HTTPException(429, "Demasiadas tentativas. Aguarde antes de tentar novamente.")
    entries.append(now); _RATE[key] = entries

def client_key(request: Request, prefix: str):
    return prefix + ":" + (request.client.host if request.client else "unknown")

def csrf_for(request: Request) -> str:
    token = request.session.get("csrf_token")
    if not token:
        token = csrf_token(); request.session["csrf_token"] = token
    return token

def verify_csrf(request: Request, supplied: str):
    expected = request.session.get("csrf_token", "")
    if not expected or not supplied or not hmac.compare_digest(expected, supplied):
        raise HTTPException(403, "Token CSRF inválido. Atualize a página e tente novamente.")

def current_company(request: Request):
    company_id = request.session.get("company_id")
    if not company_id: return None
    with connect() as db:
        return db.execute("SELECT id, name, username FROM companies WHERE id=?", (company_id,)).fetchone()

def require_company(request: Request):
    company = current_company(request)
    if not company: raise HTTPException(status_code=401, detail="Sessão não autenticada")
    return company

def audit(db, company_id, actor, action, object_id=None, detail=""):
    db.execute("INSERT INTO audit_log(company_id,actor,action,object_id,detail,created_at) VALUES(?,?,?,?,?,?)",
               (company_id, actor, action, object_id, detail[:500], utc_now_iso()))

def validate_amount(value: str) -> int:
    if not isinstance(value, str) or len(value) > 32:
        raise ValueError("valor inválido")
    normalized = value.strip().replace(" ", "")
    if "," in normalized and "." in normalized:
        raise ValueError("use apenas um separador decimal; exemplo: 1234,56")
    normalized = normalized.replace(",", ".")
    try: amount = Decimal(normalized)
    except InvalidOperation as exc: raise ValueError("valor inválido") from exc
    if not amount.is_finite(): raise ValueError("valor deve ser finito")
    if amount <= 0 or amount > Decimal(10**10): raise ValueError("o valor deve ser positivo e válido")
    try:
        with localcontext() as ctx:
            ctx.prec = 50
            cents = (amount * 100).quantize(Decimal("1"), rounding=ROUND_HALF_UP)
    except InvalidOperation as exc:
        raise ValueError("valor fora do intervalo permitido") from exc
    cents_int = int(cents)
    if cents_int <= 0 or cents_int > 10**12: raise ValueError("o valor deve ser positivo e válido")
    return cents_int

def secure_base_url(url: str):
    from urllib.parse import urlparse
    parsed = urlparse(url)
    local_hosts = {"localhost", "127.0.0.1", "::1"}
    if parsed.scheme == "https" and parsed.hostname: return url.rstrip("/")
    if parsed.scheme == "http" and parsed.hostname in local_hosts and not _is_production(): return url.rstrip("/")
    raise HTTPException(400, "A ativação exige HTTPS; HTTP só é permitido para localhost em desenvolvimento.")

@app.middleware("http")
async def security_headers(request: Request, call_next):
    response = await call_next(request)
    response.headers["X-Content-Type-Options"] = "nosniff"
    response.headers["X-Frame-Options"] = "DENY"
    response.headers["Referrer-Policy"] = "strict-origin-when-cross-origin"
    response.headers["Permissions-Policy"] = "camera=(), microphone=(), geolocation=()"
    if _is_production(): response.headers["Content-Security-Policy"] = "default-src 'self'; style-src 'self' 'unsafe-inline'; form-action 'self'; frame-ancestors 'none'; base-uri 'self'"
    return response

@app.get("/", response_class=HTMLResponse)
def home(request: Request):
    if current_company(request): return RedirectResponse("/dashboard", status_code=303)
    return templates.TemplateResponse(request=request, name="login.html", context={"error": None, "csrf_token": csrf_for(request)})

@app.get("/registo", response_class=HTMLResponse)
def register_page(request: Request):
    return templates.TemplateResponse(request=request, name="register.html", context={"error": None, "csrf_token": csrf_for(request)})

@app.post("/registo", response_class=HTMLResponse)
def register(request: Request, csrf_token_form: str = Form(..., alias="csrf_token"), company_name: str = Form(...), username: str = Form(...), password: str = Form(...)):
    verify_csrf(request, csrf_token_form); rate_limit(client_key(request, "register"), 4, 3600)
    company_name, username = company_name.strip(), username.strip().lower()
    if len(company_name) < 2 or len(company_name) > 120 or len(username) < 3 or len(username) > 60 or len(password) < 12:
        return templates.TemplateResponse(request=request, name="register.html", context={"error": "Indique uma empresa válida e uma senha com pelo menos 12 caracteres.", "csrf_token": csrf_for(request)}, status_code=400)
    company_id, code = str(uuid4()), make_activation_code()
    expires = (datetime.now(timezone.utc) + timedelta(hours=24)).isoformat().replace("+00:00", "Z")
    try:
        with connect() as db:
            company_cols = {r["name"] for r in db.execute("PRAGMA table_info(companies)").fetchall()}
            if "activation_code" in company_cols:
                # Legacy schema compatibility: store only an unusable tombstone in the old NOT NULL column.
                db.execute("INSERT INTO companies(id,name,username,password_hash,activation_code,activation_code_hash,activation_expires_at) VALUES(?,?,?,?,?,?,?)",
                           (company_id, company_name, username, hash_password(password), "INVALIDATED-"+company_id, hash_secret(code), expires))
            else:
                db.execute("INSERT INTO companies(id,name,username,password_hash,activation_code_hash,activation_expires_at) VALUES(?,?,?,?,?,?)",
                           (company_id, company_name, username, hash_password(password), hash_secret(code), expires))
            audit(db, company_id, username, "company.registered", company_id, "Empresa criada; código de ativação válido por 24 horas")
    except Exception:
        return templates.TemplateResponse(request=request, name="register.html", context={"error": "Não foi possível criar a conta. Verifique os dados e tente novamente.", "csrf_token": csrf_for(request)}, status_code=400)
    request.session.clear(); request.session["company_id"] = company_id; request.session["csrf_token"] = csrf_token()
    return templates.TemplateResponse(request=request, name="activation.html", context={"company_name": company_name, "activation_code": code, "csrf_token": csrf_for(request)})

@app.post("/login", response_class=HTMLResponse)
def login(request: Request, csrf_token_form: str = Form(..., alias="csrf_token"), username: str = Form(...), password: str = Form(...)):
    rate_limit(client_key(request, "login"), 8, 300)
    verify_csrf(request, csrf_token_form)
    with connect() as db: company = db.execute("SELECT * FROM companies WHERE username=?", (username.strip().lower(),)).fetchone()
    if not company or not verify_password(password, company["password_hash"]):
        # Generic response avoids revealing whether the username exists.
        return templates.TemplateResponse(request=request, name="login.html", context={"error": "Credenciais inválidas.", "csrf_token": csrf_for(request)}, status_code=401)
    request.session.clear(); request.session["company_id"] = company["id"]; request.session["csrf_token"] = csrf_token()
    return RedirectResponse("/dashboard", status_code=303)

@app.post("/logout")
def logout(request: Request, csrf_token_form: str = Form(..., alias="csrf_token")):
    verify_csrf(request, csrf_token_form); request.session.clear()
    return RedirectResponse("/", status_code=303)

@app.get("/dashboard", response_class=HTMLResponse)
def dashboard(request: Request):
    company = require_company(request)
    with connect() as db:
        rows = db.execute("SELECT kind, COALESCE(SUM(amount_cents),0) AS total FROM transactions WHERE company_id=? GROUP BY kind", (company["id"],)).fetchall()
        recent = db.execute("SELECT * FROM transactions WHERE company_id=? ORDER BY occurred_at DESC LIMIT 8", (company["id"],)).fetchall()
        pending = db.execute("SELECT COUNT(*) FROM transactions WHERE company_id=? AND synced=0", (company["id"],)).fetchone()[0]
    totals = {r["kind"]: r["total"] for r in rows}; income, expense = totals.get("receita", 0), totals.get("despesa", 0)
    return templates.TemplateResponse(request=request, name="dashboard.html", context={"company": company, "income": income, "expense": expense, "balance": income-expense, "recent": recent, "pending": pending, "csrf_token": csrf_for(request)})

@app.post("/financeiro/movimento")
def add_transaction(request: Request, csrf_token_form: str = Form(..., alias="csrf_token"), kind: str = Form(...), category: str = Form(...), description: str = Form(...), amount: str = Form(...)):
    company = require_company(request); verify_csrf(request, csrf_token_form)
    if kind not in {"receita", "despesa"}: raise HTTPException(400, "Tipo de movimento inválido")
    try: amount_cents = validate_amount(amount)
    except ValueError as exc: raise HTTPException(400, str(exc))
    category, description = category.strip(), description.strip()
    if not category or len(category) > 80 or not description or len(description) > 240: raise HTTPException(400, "Categoria ou descrição inválida")
    tx_id = str(uuid4()); occurred = utc_now_iso()
    with connect() as db:
        db.execute("INSERT INTO transactions(id,company_id,kind,category,description,amount_cents,source,synced,occurred_at,created_by) VALUES(?,?,?,?,?,?,?,1,?,?)",
                   (tx_id, company["id"], kind, category, description, amount_cents, "online", occurred, company["username"]))
        audit(db, company["id"], company["username"], "transaction.created", tx_id, json.dumps({"kind":kind,"amount_cents":amount_cents}))
    return RedirectResponse("/dashboard", status_code=303)


@app.post("/ativacao/novo", response_class=HTMLResponse)
def renew_activation(request: Request, csrf_token_form: str = Form(..., alias="csrf_token")):
    company = require_company(request); verify_csrf(request, csrf_token_form)
    code = make_activation_code(); expires = (datetime.now(timezone.utc) + timedelta(hours=24)).isoformat().replace("+00:00", "Z")
    with connect() as db:
        db.execute("UPDATE companies SET activation_code_hash=?,activation_expires_at=?,activation_used_at=NULL WHERE id=?", (hash_secret(code), expires, company["id"]))
        audit(db, company["id"], company["username"], "activation.renewed", company["id"], "Novo código de uso único válido por 24 horas")
    return templates.TemplateResponse(request=request, name="activation.html", context={"company_name": company["name"], "activation_code": code, "csrf_token": csrf_for(request)})

@app.post("/api/device/activate")
def activate_device(payload: dict, request: Request):
    code = str(payload.get("activation_code", "")).strip().upper(); device_id = str(payload.get("device_id", ""))
    if len(device_id) < 8 or len(device_id) > 128: raise HTTPException(400, "device_id inválido")
    # Public activation endpoint only accepts TLS outside local development.
    if request.url.scheme != "https" and request.url.hostname not in {"localhost", "127.0.0.1", "::1"}: raise HTTPException(400, "HTTPS obrigatório")
    now = utc_now_iso(); token = secrets.token_urlsafe(48)
    with connect() as db:
        company = db.execute("SELECT id,name,activation_expires_at,activation_used_at,activation_code_hash FROM companies WHERE activation_code_hash=?", (hash_secret(code),)).fetchone()
        if not company or company["activation_used_at"] or not company["activation_expires_at"] or company["activation_expires_at"] < now:
            raise HTTPException(403, "Código inválido, expirado ou já utilizado. Gere um novo código no portal autenticado.")
        existing = db.execute("SELECT company_id FROM activation_devices WHERE device_id=?", (device_id,)).fetchone()
        if existing: raise HTTPException(409, "Este dispositivo já está associado. Revogue-o antes de reativar.")
        db.execute("INSERT INTO activation_devices(device_id,company_id,token_hash) VALUES(?,?,?)", (device_id, company["id"], hash_secret(token)))
        db.execute("UPDATE companies SET activation_used_at=? WHERE id=?", (now, company["id"]))
        audit(db, company["id"], "device:"+device_id, "device.activated", device_id, "Ativação de uso único")
    return {"ok": True, "company_id": company["id"], "company_name": company["name"], "device_token": token}

@app.post("/api/sync/push")
def sync_push(payload: dict, authorization: str | None = Header(default=None)):
    if not authorization or not authorization.lower().startswith("bearer "): raise HTTPException(401, "Token do dispositivo obrigatório")
    token = authorization.split(" ",1)[1].strip(); device_id = str(payload.get("device_id", "")); events = payload.get("events", [])
    if not device_id or len(device_id) > 128 or not isinstance(events, list) or len(events) > 500: raise HTTPException(400, "Pedido de sincronização inválido (máximo 500 eventos)")
    if len(json.dumps(payload, ensure_ascii=False).encode("utf-8")) > 1_000_000: raise HTTPException(413, "Lote demasiado grande")
    with connect() as db:
        device = db.execute("SELECT company_id,token_hash,revoked_at FROM activation_devices WHERE device_id=?", (device_id,)).fetchone()
        if not device or device["revoked_at"] or not hmac.compare_digest(device["token_hash"], hash_secret(token)):
            raise HTTPException(403, "Dispositivo não autenticado ou revogado")
        created, duplicate, conflicts, rejected = [], [], [], []
        for event in events:
            event_label = event.get("event_id", "desconhecido") if isinstance(event, dict) else "desconhecido"
            try:
                if not isinstance(event, dict): raise ValueError("evento deve ser objeto")
                event_id = str(UUID(str(event["event_id"])))
                kind = str(event["kind"])
                if kind not in {"receita", "despesa"}: raise ValueError("tipo inválido")
                raw_cents = event["amount_cents"]
                if isinstance(raw_cents, bool) or not isinstance(raw_cents, (int, float)) or not float(raw_cents).is_integer(): raise ValueError("amount_cents deve ser inteiro")
                cents = int(raw_cents)
                if cents <= 0 or cents > 10**12: raise ValueError("valor inválido")
                category = str(event.get("category", "Geral"))[:80].strip() or "Geral"
                description = str(event.get("description", ""))[:240].strip()
                if not description: raise ValueError("descrição obrigatória")
                occurred = normalize_timestamp(event.get("occurred_at"))
                existing = db.execute("SELECT kind,category,description,amount_cents,occurred_at FROM transactions WHERE company_id=? AND id=?", (device["company_id"], event_id)).fetchone()
                fingerprint = (kind, category, description, cents, occurred)
                if existing:
                    old = (existing["kind"], existing["category"], existing["description"], existing["amount_cents"], existing["occurred_at"])
                    if old == fingerprint: duplicate.append(event_id)
                    else: conflicts.append({"event_id":event_id,"reason":"ID já existe com conteúdo diferente"})
                    continue
                db.execute("INSERT INTO transactions(id,company_id,kind,category,description,amount_cents,source,synced,occurred_at,device_id) VALUES(?,?,?,?,?,?,?,1,?,?)",
                           (event_id, device["company_id"], kind, category, description, cents, "offline-sync", occurred, device_id))
                audit(db, device["company_id"], "device:"+device_id, "transaction.synced", event_id, json.dumps({"kind":kind,"amount_cents":cents}))
                created.append(event_id)
            except (KeyError, TypeError, ValueError, OverflowError, InvalidOperation) as exc:
                rejected.append({"event_id": str(event_label)[:80], "reason": str(exc)[:160]})
        return {"ok": True, "created": created, "duplicate": duplicate, "conflicts": conflicts, "rejected": rejected}

@app.get("/health")
def health():
    try:
        with connect() as db: db.execute("SELECT 1").fetchone()
        return {"status":"ok", "database":"ok", "service":"AlphaTech-JLC Business Hybrid", "version":app.version}
    except Exception:
        raise HTTPException(503, "Serviço indisponível")
